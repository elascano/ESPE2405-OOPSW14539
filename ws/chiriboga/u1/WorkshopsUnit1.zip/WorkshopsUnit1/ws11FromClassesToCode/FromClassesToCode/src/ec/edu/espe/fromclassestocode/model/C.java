package ec.edu.espe.fromclassestocode.model;


/**
 *
 * @author Kerlly Chiriboga, ODS
 */
public class C {

    @Override
    public String toString() {
        return "C{" + '}';
    }

}

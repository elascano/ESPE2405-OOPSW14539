if __name__ == "__main__":
    from farm_simulator.view import chicken_farm_simulator
    chicken_farm_simulator.run()

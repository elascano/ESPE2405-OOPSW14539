# chicken_farm_simulator.py

from farm_simulator.menu import Menu

def run():
    Menu.showMenu()

if __name__ == "__main__":
    run()

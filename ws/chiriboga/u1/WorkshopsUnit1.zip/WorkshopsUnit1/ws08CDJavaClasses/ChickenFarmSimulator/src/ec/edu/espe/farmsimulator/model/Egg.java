
package ec.edu.espe.farmsimulator.model;

/**
 *
 * @author Kerlly Chiriboga, ODS
 */
public class Egg {
    
}

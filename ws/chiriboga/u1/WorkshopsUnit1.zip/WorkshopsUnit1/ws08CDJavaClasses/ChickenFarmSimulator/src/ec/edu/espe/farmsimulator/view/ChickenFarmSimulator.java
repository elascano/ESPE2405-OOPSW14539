package ec.edu.espe.farmsimulator.view;

import ec.edu.espe.farmsimulator.menu.Menu;

/**
 *
 * @author Kerlly Chiriboga, ODS
 */

public class ChickenFarmSimulator {
    public static void main(String[] args){
        Menu.showMenu();
    }
}


package ec.edu.espe.savecellphone.view;

import ec.edu.espe.savecellphone.menu.Menu;

/**
 *
 * @author Kerlly Chiriboga, ODS
 */
public class SaveCellPhoneSystem {
    public static void main(String[] args) {
        Menu.showMenu();
    }
    
}

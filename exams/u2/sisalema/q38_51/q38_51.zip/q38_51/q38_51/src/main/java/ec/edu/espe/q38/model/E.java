/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q38.model;

/**
 *
 * @author Yostin Sisalema,Code Master, DCCO-ESPE
 */
public class E {

    public E() {
    }

    @Override
    public String toString() {
        return "E{" + '}';
    }
    
}

package ec.edu.espe.hw27_template.view;

/**
 *
 * @author Damian Toscano
 */
public class UserView {

    public void displayUsername(String username) {
        System.out.println("Your username is: " + username);
    }
}

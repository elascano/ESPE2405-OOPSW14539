package ec.edu.espe.hw25_singleton.model;

/**
 *
 * @author Damian Toscano
 */
public abstract class Menu {

    public String caption;

    public abstract void paint();
}

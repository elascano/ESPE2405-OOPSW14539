package ec.edu.espe.hw25_singleton.model;

/**
 *
 * @author Damian Toscano
 */
public abstract class Button {

    public String caption;
    public abstract void paint();
}

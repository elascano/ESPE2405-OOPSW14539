
package ec.edu.espe.calculateincometax.view;

import ec.edu.espe.calculateincometax.menu.Menu;



/**
 *
 * @author Kerlly Chiriboga, ODS
 */
public class SalaryCalculatorSystem {
    public static void main(String[] args) {
        Menu.showMenu();     
    }
}

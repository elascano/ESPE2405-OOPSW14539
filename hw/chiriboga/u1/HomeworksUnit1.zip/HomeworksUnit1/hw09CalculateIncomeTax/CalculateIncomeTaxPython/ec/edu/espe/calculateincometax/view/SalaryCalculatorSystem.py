from menu import show_menu

def main():
    show_menu()

if __name__ == "__main__":
    main()


package ec.edu.espe.saveanobject.view;

import static ec.edu.espe.saveanobject.menu.Menu.showMenu;


/**
 *
 * @author Kerlly Chiriboga, ODS
 */
public class ComputerSave {
    public static void main(String[] args) {
        showMenu();
    }
}

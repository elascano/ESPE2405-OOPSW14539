from menu.Menu import showMenu
def main():
    showMenu()

if __name__ == "__main__":
    main()
